# My Custom Fritzing Parts
This is my custom Fritzing parts i have made to use in my projects.

